package com.cg.account.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Account_details")
public class Account {

	@Id
	private long account_Number;
	private String holder_Name;
	private double balance;
	
	public Account() {
		super();

	}
	
	
	
	public Account(long account_Number, String holder_Name, double balance) {
		super();
		this.account_Number = account_Number;
		this.holder_Name = holder_Name;
		this.balance = balance;
	}



	public long getAccount_Number() {
		return account_Number;
	}



	public void setAccount_Number(long account_Number) {
		this.account_Number = account_Number;
	}



	public String getHolder_Name() {
		return holder_Name;
	}



	public void setHolder_Name(String holder_Name) {
		this.holder_Name = holder_Name;
	}



	public double getBalance() {
		return balance;
	}



	public void setBalance(double balance) {
		this.balance = balance;
	}



	@Override
	public String toString() {
		return "Account [account_Number=" + account_Number + ", holder_Name=" + holder_Name + ", balance=" + balance
				+ "]";
	}



	

}

package com.cg.account.service;

import java.util.List;

import com.cg.account.entity.Account;
import com.cg.account.exception.AccountNotFoundException;

public interface AccountServices {

	boolean updateAccounts(long account_number, Account acc) throws javax.security.auth.login.AccountNotFoundException;

	boolean createAccounts(Account acc) throws javax.security.auth.login.AccountNotFoundException;

	boolean deleteAccounts(long account_number) throws javax.security.auth.login.AccountNotFoundException;

	Account getAccount(long account_number) throws javax.security.auth.login.AccountNotFoundException;

	List<Account> getAllAccounts() throws javax.security.auth.login.AccountNotFoundException;

	
}

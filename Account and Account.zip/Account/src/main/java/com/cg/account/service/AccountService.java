package com.cg.account.service;

import java.util.List;

import javax.security.auth.login.AccountNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.account.entity.Account;
import com.cg.account.repository.AccountRepository;

@Service
public class AccountService implements AccountServices {

	@Autowired
	private AccountRepository repository;
	
	@Override
	public boolean createAccounts(Account acc) throws AccountNotFoundException {

		if((repository.findById(acc.getAccount_Number()).isEmpty())) {
			repository.save(acc);
			return true;
		}else {
			throw new AccountNotFoundException("Account Already exists!!");
		}
	}

	@Override
	public boolean updateAccounts(long account_number, Account acc) throws AccountNotFoundException {

		Account accounts= repository.findById(account_number).get();
		if(accounts!=null) {
			
			accounts.setAccount_Number(acc.getAccount_Number());
			accounts.setHolder_Name(acc.getHolder_Name());
			accounts.setBalance(acc.getBalance());
			
			repository.save(accounts);
			return true;
		}
		else {
			throw new AccountNotFoundException("Account Not Found!!");
		}
	}

	@Override
	public boolean deleteAccounts(long account_number) throws AccountNotFoundException {

		Account acc= repository.findById(account_number).get();
		if(acc!=null) {
			repository.delete(acc);
			return true;
		}
		else {
			throw new AccountNotFoundException("Account Not Found!!");
		}
	}

	@Override
	public Account getAccount(long account_number) throws AccountNotFoundException {

		Account acc= repository.findById(account_number).get();
		if(acc!= null) {
			return acc;
		}
		else {
			throw new AccountNotFoundException("Account Not Found!!");
		}
	}

	@Override
	public List<Account> getAllAccounts() throws AccountNotFoundException {

		if(repository.findAll().isEmpty()) {
			throw new AccountNotFoundException("Account Not Found!!");
	}
	return repository.findAll();
	}

	}

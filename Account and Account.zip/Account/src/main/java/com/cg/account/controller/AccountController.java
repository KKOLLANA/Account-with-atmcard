package com.cg.account.controller;

import java.util.List;

import javax.security.auth.login.AccountNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.account.entity.Account;

import com.cg.account.service.AccountService;

@RestController
@RequestMapping("/account")
public class AccountController {

	@Autowired
	private AccountService service;
	
    @PostMapping("/addAccount")
	public ResponseEntity<String> createAccounts(@RequestBody Account acc) {
		
		try {
			service.createAccounts(acc);
		} catch (AccountNotFoundException e) {
			e.printStackTrace();
		}
		return new ResponseEntity<>("Account Created", HttpStatus.OK);
	}
    @PutMapping("/updateAccount/{account_number}")
	public ResponseEntity<String> updateAccount(@PathVariable long account_number, @RequestBody Account acc){
		try {
			if(service.updateAccounts(account_number, acc)) {
				return new ResponseEntity<>("Account Updated!!", HttpStatus.OK);
			}
		} catch (AccountNotFoundException e) {

			e.printStackTrace();
		}
		return new ResponseEntity<>("No such id Exists!!", HttpStatus.NOT_FOUND);
	}
    
    @DeleteMapping("/deleteAccount/{account_number}/")
	public ResponseEntity<String> deleteAtmCard(@PathVariable long account_number){
		try {
			if(service.deleteAccounts(account_number)) {
				return new ResponseEntity<String>("Account deleted !!", HttpStatus.OK);
			}
		} catch (AccountNotFoundException e) {

			e.printStackTrace();
		}
		return new ResponseEntity<>("No such id Exists!!", HttpStatus.NOT_FOUND);
	}
    @GetMapping("/getAccount/{account_number}")
	public ResponseEntity<Account> getCard(@PathVariable long account_number){
		Account acc;
		try {
			acc = service.getAccount(account_number);
			if(acc!=null) {
				return new ResponseEntity<>(acc, HttpStatus.OK);
			}
		} catch (AccountNotFoundException e) {

			e.printStackTrace();
		}
		
		
		return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
	}
    @GetMapping("/allAccounts")
	public ResponseEntity<List<Account>> getAllAccounts(){
		List<Account> accounts;
		try {
			
			accounts = service.getAllAccounts();
			if(accounts!=null) {
				return new ResponseEntity<>(accounts, HttpStatus.OK);
			}
		} catch (AccountNotFoundException e) {

			e.printStackTrace();
		}
		
		return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
	}
}

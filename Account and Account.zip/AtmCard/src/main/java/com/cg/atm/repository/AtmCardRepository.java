package com.cg.atm.repository;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.atm.entity.AtmCard;

@Repository
public interface AtmCardRepository extends JpaRepository<AtmCard, String>{



	
}

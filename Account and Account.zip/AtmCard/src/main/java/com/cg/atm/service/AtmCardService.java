package com.cg.atm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.atm.entity.AtmCard;
import com.cg.atm.exception.CardNotFoundException;
import com.cg.atm.repository.AtmCardRepository;

@Service
public class AtmCardService implements AtmCardServices {

	@Autowired
	private AtmCardRepository repository;
	
	@Override
	public boolean createAtmCards(AtmCard card) throws CardNotFoundException {

		if((repository.findById(card.getCard_Number()).isEmpty())) {
			repository.save(card);
			return true;
		}else {
			throw new CardNotFoundException("AtmCard Already exists!!");
		}
	}

	@Override
	public boolean updateAtmCards(String card_Number, AtmCard card) throws CardNotFoundException {
		
		AtmCard cards= repository.findById(card_Number).get();
		if(cards!=null) {
			
			cards.setCard_Number(card.getCard_Number());
			cards.setCard_Type(card.getCard_Type());
			cards.setCvv_Number(card.getCvv_Number());
			cards.setExpireDate(card.getExpireDate());
			cards.setAccount_Number(card.getAccount_Number());
			repository.save(cards);
			return true;
		}
		else {
			throw new CardNotFoundException("Card Not Found!!!");
		}
	}

	@Override
	public boolean deleteAtmCards(String Card_number) throws CardNotFoundException {

		AtmCard card= repository.findById(Card_number).get();
		if(card!=null) {
			repository.delete(card);
			return true;
		}
		else {
			throw new CardNotFoundException("Card Not Found!!");
		}
	}

	@Override
	public AtmCard getAtmCard(String card_Number) throws CardNotFoundException {

		AtmCard card= repository.findById(card_Number).get();
		if(card!= null) {
			return card;
		}
		else {
			throw new CardNotFoundException("Card Not Found!");
		}
	}

	@Override
	public List<AtmCard> getAllAtmCards() throws CardNotFoundException {

		if(repository.findAll().isEmpty()) {
			throw new CardNotFoundException("Card Not Found!!");
	}
	return repository.findAll();
	}

	

	}

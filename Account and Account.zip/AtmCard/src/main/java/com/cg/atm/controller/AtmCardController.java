package com.cg.atm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.atm.entity.AtmCard;
import com.cg.atm.exception.CardNotFoundException;
import com.cg.atm.service.AtmCardService;

@RestController
@RequestMapping("/api")
public class AtmCardController {

	@Autowired
	private AtmCardService service;
	
    @PostMapping("/addCard")
	public ResponseEntity<String> createCards(@RequestBody AtmCard card) {
		
		try {
			service.createAtmCards(card);
		} catch (CardNotFoundException e) {

			e.printStackTrace();
		}
		return new ResponseEntity<>("AtmCard Created", HttpStatus.OK);
	}
    @PutMapping("/updateCards/{card_Number}")
	public ResponseEntity<String> updateCard(@PathVariable String card_Number, @RequestBody AtmCard card){
		try {
			if(service.updateAtmCards(card_Number, card)) {
				return new ResponseEntity<>("AtmCard Updated!!", HttpStatus.OK);
			}
		} catch (CardNotFoundException e) {

			e.printStackTrace();
		}
		return new ResponseEntity<>("No such id Exists!!", HttpStatus.NOT_FOUND);
	}
    
    @DeleteMapping("/deleteCard/{card_Number}")
	public ResponseEntity<String> deleteAtmCard(@PathVariable String card_Number){
		try {
			if(service.deleteAtmCards(card_Number)) {
				return new ResponseEntity<String>("AtmCard deleted !!", HttpStatus.OK);
			}
		} catch (CardNotFoundException e) {

			e.printStackTrace();
		}
		return new ResponseEntity<>("No such id Exists!!", HttpStatus.NOT_FOUND);
	}
    @GetMapping("/getCard/{card_Number}")
	public ResponseEntity<AtmCard> getCard(@PathVariable String card_Number){
		AtmCard card;
		try {
			card = service.getAtmCard(card_Number);
			if(card!=null) {
				return new ResponseEntity<>(card, HttpStatus.OK);
			}
		} catch (CardNotFoundException e) {

			e.printStackTrace();
		}
		
		
		return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
	}
    @GetMapping("/allCards")
	public ResponseEntity<List<AtmCard>> getAllCards(){
		List<AtmCard> cards;
		try {
			
			cards = service.getAllAtmCards();
			if(cards!=null) {
				return new ResponseEntity<>(cards, HttpStatus.OK);
			}
		} catch (CardNotFoundException e) {
	
			e.printStackTrace();
		}
		
		return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
	}
}

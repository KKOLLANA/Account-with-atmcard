package com.cg.atm.service;

import java.util.List;
import com.cg.atm.entity.AtmCard;
import com.cg.atm.exception.CardNotFoundException;

public interface AtmCardServices {

	
	boolean createAtmCards(AtmCard card) throws CardNotFoundException;

	boolean updateAtmCards(String card_Number, AtmCard card) throws CardNotFoundException;

	boolean deleteAtmCards(String Card_number) throws CardNotFoundException;
	
	public AtmCard getAtmCard(String card_Number) throws CardNotFoundException;

	public List<AtmCard> getAllAtmCards() throws CardNotFoundException;

	

	
	
	
}

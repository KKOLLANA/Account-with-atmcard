package com.cg.atm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtmCardApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtmCardApplication.class, args);
	}

}

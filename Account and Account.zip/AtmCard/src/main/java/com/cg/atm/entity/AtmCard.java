package com.cg.atm.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="AtmCardDetails")
public class AtmCard {

	@Id
	private String card_Number;
	private String card_Type;
	private int cvv_Number;
	private String expireDate;
	private long account_Number;
	
	
	public AtmCard() {
		super();
	}
	public AtmCard( String card_Number, String card_Type, int cvv_Number, String expireDate,
			long account_Number	) {
		
		super();
		
		this.card_Number = card_Number;
		this.card_Type = card_Type;
		this.cvv_Number = cvv_Number;
		this.expireDate = expireDate;
		this.account_Number = account_Number;
		
	}
	
	public String getCard_Number() {
		return card_Number;
	}
	public void setCard_Number(String card_Number) {
		this.card_Number = card_Number;
	}
	public String getCard_Type() {
		return card_Type;
	}
	public void setCard_Type(String card_Type) {
		this.card_Type = card_Type;
	}
	public int getCvv_Number() {
		return cvv_Number;
	}
	public void setCvv_Number(int cvv_Number) {
		this.cvv_Number = cvv_Number;
	}
	public String getExpireDate() {
		return expireDate;
	}
	public void setExpireDate(String expireDate) {
		this.expireDate = expireDate;
	}
	public long getAccount_Number() {
		return account_Number;
	}
	public void setAccount_Number(long account_Number) {
		this.account_Number = account_Number;
	}
	@Override
	public String toString() {
		return " card_Number=" + card_Number + ", card_Type=" + card_Type
				+ ", cvv_Number=" + cvv_Number + ", expireDate=" + expireDate + ", account_Number=" + account_Number
				+ "]";
	}
	

}

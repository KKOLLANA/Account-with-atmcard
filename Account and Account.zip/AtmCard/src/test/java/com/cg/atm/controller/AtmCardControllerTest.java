package com.cg.atm.controller;

		import static org.mockito.Mockito.when;
		import java.util.ArrayList;
		import java.util.List;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
		import org.springframework.boot.test.context.SpringBootTest;

import com.cg.atm.entity.AtmCard;
import com.cg.atm.repository.AtmCardRepository;
import com.cg.atm.service.AtmCardService;

		

		@SpringBootTest(classes = { AtmCardControllerTest.class })
		class AtmCardControllerTest {
			@Mock
			AtmCardRepository atmCardRepository;
			AtmCardService atmCardService;
			
			public List<AtmCard> atmcard;
			@Test
			void test_getAtmCard() {

				List<AtmCard> atmCard = new ArrayList<AtmCard>();

				atmCard.add(new AtmCard("78829937865", "Visa ",123,"21-01-23",12378999));
				atmCard.add(new AtmCard("74895433688 ", "Master",421,"12-4-23",23478556));

				when(atmCardRepository.findAll()).thenReturn(atmCard); // mocking statement
			
			}
			@Test
			
			void test_addAtmCard() {

				AtmCard atmCard = (new AtmCard("78829937865", "Visa ",123,"21-01-23",12378999));

				when(atmCardRepository.save(atmCard)).thenReturn(atmCard);


}}